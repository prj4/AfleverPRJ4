﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhotoBookDatabase.Model;

//TODO: Missing implementation
namespace PhotoBook.Repository.PictureRepository
{
    public interface IPictureRepository
    {
        /// <summary>
        /// Return all pictures
        /// </summary>
        Task<IEnumerable<Picture>> GetPictures();
        /// <summary>
        /// Return all pictures attached to an event by event pin
        /// </summary>
        Task<IEnumerable<Picture>> GetPicturesByEventPin(string eventPin);
        /// <summary>
        /// Return all pictures attached to an event and taken by specific host
        /// </summary>
        Task<IEnumerable<Picture>> GetPicturesByEventPinAndHostId(string eventPin, int hostId);
        /// <summary>
        /// Return all pictures attached to an event and taken by specific guest
        /// </summary>
        Task<IEnumerable<Picture>> GetPicturesByEventPinAndGuestId(string eventPin, int guestId);
        /// <summary>
        /// Return specific picture by id
        /// </summary>
        Task<Picture> GetPictureById(int pictureId);
        /// <summary>
        /// Insert picture
        /// </summary>
        Task<int> InsertPicture(Picture picture);
        /// <summary>
        /// Delete picture by id
        /// </summary>
        Task DeletePictureById(int pictureId);
        
    }
}
