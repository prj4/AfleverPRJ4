﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhotoBookDatabase.Model;

//TODO: Maybe change so dont use function overload
namespace PhotoBook.Repository.HostRepository
{
    public interface IHostRepository
    {
        /// <summary>
        /// Return all hosts
        /// </summary>
        Task<IEnumerable<Host>> GetHosts();
        /// <summary>
        /// Return specific host by id
        /// </summary>
        Task<Host> GetHostById(int hostId);
        /// <summary>
        /// Returns specific host by email
        /// </summary>
        Task<Host> GetHostByEmail(string email);
        /// <summary>
        /// Insert host 
        /// </summary>
        Task InsertHost(Host host);
        /// <summary>
        /// Delete specific host by id
        /// </summary>
        Task DeleteHostById(int hostId);
        /// <summary>
        /// Delete specfic host by email
        /// </summary>
        Task DeleteHostByEmail(string email);
        /// <summary>
        /// Update host
        /// </summary>
        Task UpdateHost(Host host);
    }
}
