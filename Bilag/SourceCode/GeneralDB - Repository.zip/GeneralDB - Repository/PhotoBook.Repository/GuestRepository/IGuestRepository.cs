﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhotoBookDatabase.Model;

//TODO: Maybe change so dont use function overload
namespace PhotoBook.Repository.GuestRepository
{
    public interface IGuestRepository
    {
        /// <summary>
        /// Return all guests
        /// </summary>
        Task<IEnumerable<Guest>> GetGuests();
        /// <summary>
        /// Return specific guest by id
        /// </summary>
        Task<Guest> GetGuestById(int guestId);
        /// <summary>
        /// Return specific guest by name and pin
        /// </summary>
        Task<Guest> GetGuestByNameAndEventPin(string name, string eventPin);
        /// <summary>
        /// Insert guest
        /// </summary>
        Task InsertGuest(Guest guest);
        /// <summary>
        /// Delete specfic guest by id
        /// </summary>
        Task DeleteGuestById(int id);
        /// <summary>
        /// Delete specfic guest by name and event pin
        /// </summary>
        Task DeleteGuestByNameAndEventPin(string name, string eventPin);
        /// <summary>
        /// Update guest 
        /// </summary>
        Task UpdateGuest(Guest guest);
    }
}
