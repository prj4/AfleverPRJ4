﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhotoBookDatabase.Model;

namespace PhotoBook.Repository.EventRepository
{
    public interface IEventRepository
    {
        /// <summary>Returns all events
        /// </summary>
        Task<IEnumerable<Event>> GetEvents();
        /// <summary>Returns single event
        /// </summary>
        Task<Event> GetEventByPin(string pin);
        /// <summary>Returns events by specific host  
        /// </summary>
        Task<IEnumerable<Event>> GetEventsByHostId(int hostId);
        /// <summary>Insert an event  
        /// </summary>
        Task InsertEvent(Event eve);
        /// <summary>Delete specific event by unique pin  
        /// </summary>
        Task DeleteEventByPin(string pin);
        /// <summary>Update event  
        /// </summary>
        Task UpdateEvent(Event eve);
    }
}
