using System;
using Xunit;

namespace PhotobookWebAPI.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
