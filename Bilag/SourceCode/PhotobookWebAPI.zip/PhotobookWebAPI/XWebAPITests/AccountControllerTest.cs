using System;
using Microsoft.AspNet.Identity;
using PhotobookWebAPI.Data;
using Xunit;

namespace XWebAPITests
{
    public class AccountControllerTest
    {
        [Fact]
        public void Test1()
        {

        }   
    }
}
